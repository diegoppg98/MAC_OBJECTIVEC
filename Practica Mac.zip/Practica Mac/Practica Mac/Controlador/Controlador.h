//
//  Controlador.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
@class Modelo;
@class ControladorLienzo;

@interface Controlador : NSObject <NSWindowDelegate,
NSTableViewDataSource, NSTableViewDelegate, NSControlTextEditingDelegate>{
    IBOutlet NSTextField *textFieldNombre;
    IBOutlet NSTextField *textFieldXmin;
    IBOutlet NSTextField *textFieldXmax;
    IBOutlet NSTextField *textFieldV1;
    IBOutlet NSTextField *textFieldV2;
    IBOutlet NSTextField *textFieldV3;
    IBOutlet NSTextField *textFieldXminPant;
    IBOutlet NSTextField *textFieldXmaxPant;
    IBOutlet NSTextField *textFieldYminPant;
    IBOutlet NSTextField *textFieldYmaxPant;
    IBOutlet NSButton *buttonAdd;
    IBOutlet NSTableView *aTableView;
    IBOutlet NSComboBox *funcionseleccionada;
    IBOutlet NSButton *buttonDelete;
    IBOutlet NSButton *buttonShow;
    IBOutlet NSButton *buttonHidden;
    IBOutlet NSButton *buttonModify;
    IBOutlet NSColorWell *selectColor;
    
    ControladorLienzo *panelController;
    Modelo *elModelo;
}
-(IBAction)buttonAdd:(id)sender;
-(IBAction)buttonDelete:(id)sender;
-(IBAction)buttonShow:(id)sender;
-(IBAction)buttonHidden:(id)sender;
-(IBAction)buttonModify:(id)sender;
-(IBAction)selectionComboBoxChanging:(id)sender;
@end
