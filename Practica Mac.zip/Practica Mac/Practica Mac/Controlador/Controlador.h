//
//  Controlador.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
@class Modelo;
@class ControladorLienzo;

@interface Controlador : NSObject <NSWindowDelegate,
NSTableViewDataSource, NSTableViewDelegate, NSControlTextEditingDelegate>{
    //NSMutableArray *aArray;
    IBOutlet NSTextField *textFieldNombre;
    IBOutlet NSTextField *textFieldXmin;
    IBOutlet NSTextField *textFieldXmax;
    IBOutlet NSTextField *textFieldV1;
    IBOutlet NSTextField *textFieldV2;
    IBOutlet NSTextField *textFieldV3;
    IBOutlet NSButton *buttonAdd;
    IBOutlet NSTableView *aTableView;
    IBOutlet NSComboBox *funcionseleccionada;
    
    //NSInteger aRowSelected;
    ControladorLienzo *panelController;
    Modelo *elModelo;
}
-(IBAction)buttonAdd:(id)sender;
@end
