//
//  Controlador.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "Controlador.h"
#import "ControladorLienzo.h"
#import "Modelo.h"
#import "Funcion.h"

@implementation Controlador

NSString * ETPanelChangeTableNotification = @"ETPanelChangeView";

- (id)init
{
    self = [super init];
    if (self) {
        elModelo = [[Modelo alloc]init];
        
    }
    return self;
}

- (IBAction)buttonAdd:(id)sender
{
    if (!panelController) {
        panelController = [[ControladorLienzo alloc]init];
    }
    NSLog(@"panel %@\n",panelController);
    [panelController showWindow:self];
   
    
    //[textField setIntValue:2];
    Funcion *nuevaFuncion;
    NSColor * c = [NSColor colorWithCalibratedRed:0.886f green:0.886f blue:0.886f alpha:1.0f];
    nuevaFuncion =[[Funcion alloc] initWithNombre:[textFieldNombre stringValue] TipoFuncion: [funcionseleccionada stringValue] Xminima:[textFieldXmin integerValue] Xmaxima:[textFieldXmax integerValue] Var1:[textFieldV1 integerValue] Var2:[textFieldV2 integerValue] Var3:[textFieldV3 integerValue] Color:c];
   
   //nuevaFuncion =[[Funcion alloc] initWithNombre:@"sin(x)" TipoFuncion: @"sin(x)"  Xminima:0 Xmaxima:6.28 Var1:6 Var2:5 Var3:6 ];
    
    NSLog(@"NUEVA FUNCION CONTIENE: %@",[nuevaFuncion TipoFuncion]);
    
    [elModelo AñadirFuncion:nuevaFuncion];
    [panelController setFunciones:[elModelo aArray]];
    [aTableView reloadData];
   NSDictionary *notinfo =[NSDictionary dictionaryWithObject:@"No" forKey:@"No"];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelChangeTableNotification object:self
        userInfo:notinfo];
}

- (NSInteger) numberOfRowsInTableView:(NSTableView *)tableView
{
    return [elModelo numberOfRows];
}

- (id) tableView:(NSTableView *)tableView
objectValueForTableColumn:(NSTableColumn *)tableColumn
             row:(NSInteger)row
{
    NSString *string = [NSString stringWithFormat:@"%@",[elModelo FuncionNombre:row]];
    NSString *string1 = [NSString stringWithFormat:@"%@",[elModelo FuncionTipoFuncion:row]];
    NSString *string2 = [NSString stringWithFormat:@"%ld", [elModelo FuncionXmin:row]];
    NSString *string3 = [NSString stringWithFormat:@"%ld", [elModelo FuncionXmax:row]];
    NSString *string4 = [NSString stringWithFormat:@"%ld", [elModelo FuncionVar1:row]];
    NSString *string5 = [NSString stringWithFormat:@"%ld", [elModelo FuncionVar2:row]];
    NSString *string6 = [NSString stringWithFormat:@"%ld", [elModelo FuncionVar3:row]];
    
    if([tableColumn.identifier isEqualToString:@"Nombre"]){
        
        return string;
    }
    else if([tableColumn.identifier isEqualToString:@"Funcion"]){
        //NSLog(@"OBJETO EN EL INDICE 2222 ES: %@",string1);
        return string1;
    }
    
    else if([tableColumn.identifier isEqualToString:@"Xmax"])
        return string2;
    
    else if([tableColumn.identifier isEqualToString:@"Xmin"])
        return string3;
    
    else if([tableColumn.identifier isEqualToString:@"Var1"])
        return string4;
    
    else if([tableColumn.identifier isEqualToString:@"Var2"])
        return string5;
    
    else
        return string6;
    
}
@end
