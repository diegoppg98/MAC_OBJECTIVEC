//
//  Controlador.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "Controlador.h"
#import "ControladorLienzo.h"
#import "Modelo.h"
#import "Funcion.h"

@implementation Controlador

NSString * ETPanelChangeTableNotification = @"ETPanelChangeView";

- (id)init
{
    self = [super init];
    if (self) {
        elModelo = [[Modelo alloc]init];
        
    }
    return self;
}

- (IBAction)buttonAdd:(id)sender
{
    
    
    if (!panelController) {
        panelController = [[ControladorLienzo alloc]init];
    }
    [panelController showWindow:self];
   
    
    Funcion *nuevaFuncion;
    NSColor * c = [selectColor color];
    nuevaFuncion =[[Funcion alloc] initWithNombre:[textFieldNombre stringValue] TipoFuncion: [funcionseleccionada stringValue] Xminima:[textFieldXmin floatValue] Xmaxima:[textFieldXmax floatValue] Var1:[textFieldV1 floatValue] Var2:[textFieldV2 floatValue] Var3:[textFieldV3 floatValue] Color:c];
   
    
    [elModelo AñadirFuncion:nuevaFuncion];
    [panelController setFunciones:[elModelo aArray]];
    [aTableView reloadData];
    
    textFieldNombre.stringValue=@"";
    funcionseleccionada.stringValue=@"Seleccione Funcion";
    textFieldXmin.stringValue=@"";
    textFieldXmax.stringValue=@"";
    textFieldV1.stringValue=@"";
    textFieldV2.stringValue=@"";
    textFieldV3.stringValue=@"";
    
}

- (NSInteger) numberOfRowsInTableView:(NSTableView *)tableView
{
    return [elModelo numberOfRows];
}

- (id) tableView:(NSTableView *)tableView
objectValueForTableColumn:(NSTableColumn *)tableColumn
             row:(NSInteger)row
{
    NSString *string = [NSString stringWithFormat:@"%@",[elModelo FuncionNombre:row]];
    NSString *string1 = [NSString stringWithFormat:@"%@",[elModelo FuncionTipoFuncion:row]];
    NSString *string2 = [NSString stringWithFormat:@"%.3f", [elModelo FuncionXmin:row]];
    NSString *string3 = [NSString stringWithFormat:@"%.3f", [elModelo FuncionXmax:row]];
    NSString *string4 = [NSString stringWithFormat:@"%.3f", [elModelo FuncionVar1:row]];
    NSString *string5 = [NSString stringWithFormat:@"%.3f", [elModelo FuncionVar2:row]];
    NSString *string6 = [NSString stringWithFormat:@"%.3f", [elModelo FuncionVar3:row]];
    NSString *string7 = [NSString stringWithFormat:@"%@",[elModelo FuncionPintar:row]];
    NSString *string8 = [NSString stringWithFormat:@"%@",[elModelo FuncionPintar:row]];
    
    
    if([tableColumn.identifier isEqualToString:@"Nombre"]){
        
        return string;
    }
    else if([tableColumn.identifier isEqualToString:@"Funcion"]){

        return string1;
    }
    else if([tableColumn.identifier isEqualToString:@"Xmin"])
        return string2;
    
    else if([tableColumn.identifier isEqualToString:@"Xmax"])
        return string3;
    
    
    else if([tableColumn.identifier isEqualToString:@"Var1"])
        return string4;
    
    else if([tableColumn.identifier isEqualToString:@"Var2"])
        return string5;
    
    else if([tableColumn.identifier isEqualToString:@"Var3"])
        return string6;
    
    else if([tableColumn.identifier isEqualToString:@"Representada"])
        return string7;
    
    else 
        return string8;
    
}



-(IBAction)buttonDelete:(id)sender{
    
    [elModelo EliminarFuncion:[aTableView selectedRow]];
    [panelController setFunciones:[elModelo aArray]];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelChangeTableNotification object:self];
    [aTableView reloadData];
}

-(IBAction)buttonShow:(id)sender{
    [elModelo RepresentarFuncion:[aTableView selectedRow]];
    [panelController setFunciones:[elModelo aArray]];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelChangeTableNotification object:self];
    
    [aTableView reloadData];
}

-(IBAction)buttonHidden:(id)sender{
    [elModelo NoRepresentarFuncion:[aTableView selectedRow]];
    [panelController setFunciones:[elModelo aArray]];

    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelChangeTableNotification object:self];
    
    [aTableView reloadData];
    
}

-(IBAction)buttonModify:(id)sender{
    if([buttonAdd isEnabled]==TRUE){
        textFieldNombre.stringValue=[elModelo FuncionNombre:[aTableView selectedRow]];
        funcionseleccionada.stringValue=[elModelo FuncionTipoFuncion:[aTableView selectedRow]];
        textFieldXmin.floatValue=[elModelo FuncionXmin:[aTableView selectedRow]];
        textFieldXmax.floatValue=[elModelo FuncionXmax:[aTableView selectedRow]];
        textFieldV1.floatValue=[elModelo FuncionVar1:[aTableView selectedRow]];
        textFieldV2.floatValue=[elModelo FuncionVar2:[aTableView selectedRow]];
        textFieldV3.floatValue=[elModelo FuncionVar3:[aTableView selectedRow]];
        selectColor.color=[elModelo FuncionColor:[aTableView selectedRow]];
        
        [buttonDelete setEnabled : NO];
        [buttonShow setEnabled : NO];
        [buttonHidden setEnabled : NO];
        [buttonAdd setEnabled : NO];
    }
    
    else{
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setNombre:textFieldNombre.stringValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setTipoFuncion:funcionseleccionada.stringValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setXminima:textFieldXmin.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setXmaxima:textFieldXmax.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setVar1:textFieldV1.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setVar2:textFieldV2.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setVar3:textFieldV3.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setColor:selectColor.color];
        [aTableView reloadData];
        
        [buttonDelete setEnabled : YES];
        [buttonShow setEnabled : YES];
        [buttonHidden setEnabled : YES];
        [buttonAdd setEnabled : YES];
        
        if([[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] Pintar] == TRUE){
            [panelController setFunciones:[elModelo aArray]];
            NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
            [nc postNotificationName:ETPanelChangeTableNotification object:self];
        }
    }
    
}


- (void)tableViewSelectionIsChanging:(NSNotification *)notification{
    [buttonDelete setEnabled : YES];
    [buttonShow setEnabled : YES];
    [buttonHidden setEnabled : YES];
    [buttonModify setEnabled : YES];
    if([aTableView selectedRow]<0){
        [buttonDelete setEnabled : NO];
        [buttonShow setEnabled : NO];
        [buttonHidden setEnabled : NO];
        [buttonModify setEnabled : NO];
    }
}

-(BOOL) selectionShouldChangeInTableView: (NSTableView *)tableView{
    if(([buttonAdd isEnabled]==NO) && ([buttonModify isEnabled]==YES))
        return NO;
    else
        return YES;
}

@end
