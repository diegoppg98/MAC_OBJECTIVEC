//
//  Controlador.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "Controlador.h"
#import "ControladorLienzo.h"
#import "Modelo.h"
#import "Funcion.h"
#import "TamPantalla.h"

@implementation Controlador

NSString * ETPanelChangeTableNotification = @"ETPanelChangeView";
NSString * ETPanelChangePantalla = @"ETPanelChangePantalla";

- (id)init
{
    self = [super init];
    if (self) {
        elModelo = [[Modelo alloc]init];
        Pantalla = [[TamPantalla alloc] init];
    }
    return self;
}

- (IBAction)buttonAdd:(id)sender
{
    
    if (!panelController) {
        panelController = [[ControladorLienzo alloc]init];
    }
    [panelController showWindow:self];
   
    
    Funcion *nuevaFuncion;
    NSColor * c = [selectColor color];
    nuevaFuncion =[[Funcion alloc] initWithNombre:[textFieldNombre stringValue] TipoFuncion: [funcionseleccionada stringValue] Xminima:[textFieldXmin floatValue] Xmaxima:[textFieldXmax floatValue] Var1:[textFieldV1 floatValue] Var2:[textFieldV2 floatValue] Var3:[textFieldV3 floatValue] Color:c];
   
    
    [elModelo AñadirFuncion:nuevaFuncion];
    [panelController setFunciones:[elModelo aArray]];
    [aTableView reloadData];
    
    textFieldNombre.stringValue=@"";
    funcionseleccionada.stringValue=@"Seleccione Funcion";
    textFieldXmin.stringValue=@"";
    textFieldXmax.stringValue=@"";
    textFieldV1.stringValue=@"";
    textFieldV2.stringValue=@"";
    textFieldV3.stringValue=@"";
    
    [textFieldNombre setEnabled : NO];
    [textFieldXmin setEnabled : NO];
    [textFieldXmax setEnabled : NO];
    [textFieldV1 setEnabled : NO];
    [textFieldV2 setEnabled : NO];
    [textFieldV3 setEnabled : NO];
    [buttonAdd setEnabled : NO];
    
    [[NSColorPanel sharedColorPanel] close];
   
}

- (NSInteger) numberOfRowsInTableView:(NSTableView *)tableView
{
    return [elModelo numberOfRows];
}

- (id) tableView:(NSTableView *)tableView
objectValueForTableColumn:(NSTableColumn *)tableColumn
             row:(NSInteger)row
{
    NSString *string = [NSString stringWithFormat:@"%@",[[[elModelo aArray] objectAtIndex:row] Nombre]];
    NSString *string1 = [NSString stringWithFormat:@"%@",[[[elModelo aArray] objectAtIndex:row] TipoFuncion]];
    NSString *string2 = [NSString stringWithFormat:@"%.2f", [[[elModelo aArray] objectAtIndex:row] Xminima]];
    NSString *string3 = [NSString stringWithFormat:@"%.2f", [[[elModelo aArray] objectAtIndex:row] Xmaxima]];
    NSString *string4 = [NSString stringWithFormat:@"%.2f", [[[elModelo aArray] objectAtIndex:row] Var1]];
    NSString *string5 = [NSString stringWithFormat:@"%.2f", [[[elModelo aArray] objectAtIndex:row] Var2]];
    NSString *string6 = [NSString stringWithFormat:@"%.2f", [[[elModelo aArray] objectAtIndex:row] Var3]];
    NSString *string7 = [NSString stringWithFormat:@"%@",[elModelo FuncionPintar:row]];
    
    
    if([tableColumn.identifier isEqualToString:@"Nombre"]){
        
        return string;
    }
    else if([tableColumn.identifier isEqualToString:@"Funcion"]){

        return string1;
    }
    else if([tableColumn.identifier isEqualToString:@"Xmin"])
        return string2;
    
    else if([tableColumn.identifier isEqualToString:@"Xmax"])
        return string3;
    
    
    else if([tableColumn.identifier isEqualToString:@"Var1"])
        return string4;
    
    else if([tableColumn.identifier isEqualToString:@"Var2"])
        return string5;
    
    else if([tableColumn.identifier isEqualToString:@"Var3"])
        return string6;
    
    else if([tableColumn.identifier isEqualToString:@"Representada"])
        return string7;
    
    else{
        NSColor *color = [[[elModelo aArray] objectAtIndex:row] Color];
        NSString * COLOR =@"COLOR";
        NSDictionary *col = @{NSForegroundColorAttributeName : color};
        NSAttributedString *colCadena = [[NSAttributedString alloc]initWithString:COLOR attributes:col];
        return colCadena;
    }
    
}



-(IBAction)buttonDelete:(id)sender{
    
    [elModelo EliminarFuncion:[aTableView selectedRow]];
    [panelController setFunciones:[elModelo aArray]];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelChangeTableNotification object:self];
    [aTableView reloadData];
}

-(IBAction)buttonShow:(id)sender{
    [elModelo RepresentarFuncion:[aTableView selectedRow]];
    [panelController setFunciones:[elModelo aArray]];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelChangeTableNotification object:self];
    
    [aTableView reloadData];
}

-(IBAction)buttonHidden:(id)sender{
    [elModelo NoRepresentarFuncion:[aTableView selectedRow]];
    [panelController setFunciones:[elModelo aArray]];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelChangeTableNotification object:self];
    [aTableView reloadData];
}

-(IBAction)buttonModify:(id)sender{
    if([[buttonModify title]isEqualToString:@"Modificar"]){
        [textFieldNombre setEnabled : YES];
        [textFieldXmin setEnabled : YES];
        [textFieldXmax setEnabled : YES];
        [textFieldV1 setEnabled : YES];
        [textFieldV2 setEnabled : YES];
        [textFieldV3 setEnabled : YES];
        
        textFieldNombre.stringValue=[[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] Nombre];
        funcionseleccionada.stringValue=[[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] TipoFuncion];
        textFieldXmin.floatValue=[[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] Xminima];
        textFieldXmax.floatValue=[[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] Xmaxima];
        textFieldV1.floatValue=[[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] Var1];
        textFieldV2.floatValue=[[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] Var2];
        textFieldV3.floatValue=[[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] Var3];
        selectColor.color=[[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] Color];
        
        if(![[funcionseleccionada stringValue] isEqualToString:@"var1*x^2+var2*x+var3"]){
            [textFieldV3 setEnabled : NO];
        }
        
        [buttonDelete setEnabled : NO];
        [buttonShow setEnabled : NO];
        [buttonHidden setEnabled : NO];
        [buttonAdd setEnabled : NO];
        [buttonModify setTitle:@"Guardar Cambios"];
    }
    
    else{
        [buttonModify setTitle:@"Modificar"];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setNombre:textFieldNombre.stringValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setTipoFuncion:funcionseleccionada.stringValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setXminima:textFieldXmin.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setXmaxima:textFieldXmax.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setVar1:textFieldV1.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setVar2:textFieldV2.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setVar3:textFieldV3.floatValue];
        [[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] setColor:selectColor.color];
        [aTableView reloadData];
        
        [buttonDelete setEnabled : YES];
        [buttonShow setEnabled : YES];
        [buttonHidden setEnabled : YES];
        
        textFieldNombre.stringValue=@"";
        funcionseleccionada.stringValue=@"Seleccione Funcion";
        textFieldXmin.stringValue=@"";
        textFieldXmax.stringValue=@"";
        textFieldV1.stringValue=@"";
        textFieldV2.stringValue=@"";
        textFieldV3.stringValue=@"";
        
        [textFieldNombre setEnabled : NO];
        [textFieldXmin setEnabled : NO];
        [textFieldXmax setEnabled : NO];
        [textFieldV1 setEnabled : NO];
        [textFieldV2 setEnabled : NO];
        [textFieldV3 setEnabled : NO];
        
        if([[[elModelo aArray] objectAtIndex:[aTableView selectedRow]] Pintar] == TRUE){
            [panelController setFunciones:[elModelo aArray]];
            NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
            [nc postNotificationName:ETPanelChangeTableNotification object:self];
        }
    }
    
}

-(IBAction)buttonTamPantalla:(id)sender{
    [Pantalla setXmin:textFieldXminPant.floatValue];
    [Pantalla setXmax:textFieldXmaxPant.floatValue];
    [Pantalla setYmin:textFieldYminPant.floatValue];
    [Pantalla setYmax:textFieldYmaxPant.floatValue];
    
    NSDictionary *notinfo =[NSDictionary dictionaryWithObject:Pantalla forKey:@"pant"];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelChangePantalla object:self
                    userInfo:notinfo];
}

- (void)tableViewSelectionIsChanging:(NSNotification *)notification{
    [buttonDelete setEnabled : YES];
    [buttonShow setEnabled : YES];
    [buttonHidden setEnabled : YES];
    [buttonModify setEnabled : YES];
    if([aTableView selectedRow]<0){
        [buttonDelete setEnabled : NO];
        [buttonShow setEnabled : NO];
        [buttonHidden setEnabled : NO];
        [buttonModify setEnabled : NO];
    }
}

-(BOOL) selectionShouldChangeInTableView: (NSTableView *)tableView{
    if([[buttonModify title]isEqualToString:@"Modificar"])
        return YES;
    else
        return NO;
}

-(IBAction)selectionComboBoxChanging:(id)sender{
    
        if(![[funcionseleccionada stringValue] isEqualToString:@"Seleccione Funcion"]){
    
            if([[funcionseleccionada stringValue] isEqualToString:@"var1*x^2+var2*x+var3"]){
            [textFieldV3 setEnabled : YES];
            }
            else
                [textFieldV3 setEnabled : NO];
        
            [textFieldNombre setEnabled : YES];
            [textFieldXmin setEnabled : YES];
            [textFieldXmax setEnabled : YES];
            [textFieldV1 setEnabled : YES];
            [textFieldV2 setEnabled : YES];
           if([[buttonModify title]isEqualToString:@"Modificar"]) [buttonAdd setEnabled : YES];
        }
}

@end
