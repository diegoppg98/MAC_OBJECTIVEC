//
//  ControladorLienzo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "ControladorLienzo.h"

#import "VistaLienzo.h"


@interface ControladorLienzo ()


@end


@implementation ControladorLienzo
@synthesize Funciones;

extern NSString * ETPanelChangeTableNotification;
extern NSString * ETPanelChangePantalla;
NSString * ETPanelAñadir = @"ETPanelAñadir";
NSString * ETPanelPantalla = @"ETPanelPantalla";


- (id) init {
    if (![super initWithWindowNibName:@"ControladorLienzo"])
        return nil;
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserver:self
           selector:@selector(handlePanelChange:) name:ETPanelChangeTableNotification object:nil];
    [nc addObserver:self
           selector:@selector(handlePanelChange2:) name:ETPanelChangePantalla object:nil];
    return self;
}
- (id)initWithWindow:(NSWindow *)window
{
    self = [super initWithWindow:window];
    if (self) {
        // Initialization code here.
    }
    return self;
}
- (void)windowDidLoad
{
    [super windowDidLoad];
}

-(void) handlePanelChange:(NSNotification *)aNotification
{

    NSDictionary *notinfo =[NSDictionary dictionaryWithObject:Funciones forKey:@"func"];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelAñadir object:self
                        userInfo:notinfo];

}

-(void) handlePanelChange2:(NSNotification *)aNotification
{
    NSDictionary *notinfo =[aNotification userInfo];
    TamPantalla * tam =[notinfo objectForKey:@"pant"];
    
    NSDictionary *notinfo2 =[NSDictionary dictionaryWithObject:tam forKey:@"pant"];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelPantalla object:self
                    userInfo:notinfo2];
    
}

-(void) drawEjes: (NSRect)b
withGraphicsContext:(NSGraphicsContext *)ctx{
    

}

-(float) valueAt: (float) x
         funcion: (Funcion *) func{
    float result = 0;
    if([[func TipoFuncion] isEqualToString:@"var1*sin(var2*x)"]) {
        result=[func Var1]*sin([func Var2]*x);
    }
    else if([[func TipoFuncion] isEqualToString:@"var1*cos(var2*x)"]){
        result=[func Var1]*cos([func Var2]*x);
    }
    else if([[func TipoFuncion] isEqualToString:@"var1*x+var2"]){
        result=[func Var1]*x+[func Var2];
    }
    else if([[func TipoFuncion] isEqualToString:@"var1*x^var2"]){
        result=[func Var1]*powf(x, [func Var2]);
    }
    else if([[func TipoFuncion] isEqualToString:@"var1/(var2*x)"]){
        result=[func Var1]/([func Var2]*x);
    }
    else if([[func TipoFuncion] isEqualToString:@"var1*x^2+var2*x+var3"]){
        result=[func Var1]*powf(x, 2)+[func Var2]*x+[func Var3];
    }
    return result;
}

-(void) drawInRect: (NSRect)b
withGraphicsContext:(NSGraphicsContext *)ctx
       withFuncion:(Funcion *)func
   withTamPantalla:(NSRect)funcRect
{
    
    if([func Pintar]==YES){
        NSPoint aPoint;
        float distance = ([func Xmaxima]-[func Xminima])/HOPS;

        [[func Polilinea] removeAllPoints];
        [ctx saveGraphicsState];
        NSAffineTransform *tf = [NSAffineTransform transform];
        [tf scaleXBy:b.size.width/funcRect.size.width
                 yBy:b.size.height/funcRect.size.height];
        
        [tf translateXBy:-funcRect.origin.x yBy:-funcRect.origin.y];
        
        [tf concat];
        
        [[NSColor blackColor] set];
        [NSBezierPath setDefaultLineWidth:0.03];
        NSPoint EjexX= NSMakePoint(funcRect.origin.x, 0);
        NSPoint EjexY= NSMakePoint(funcRect.size.width+funcRect.origin.x, 0);
        
        NSPoint EjeyX= NSMakePoint(0,funcRect.origin.y);
        NSPoint EjeyY= NSMakePoint(0, funcRect.size.height + funcRect.origin.y);
        
        [NSBezierPath strokeLineFromPoint:EjexX toPoint: EjexY];
        [NSBezierPath strokeLineFromPoint:EjeyX toPoint: EjeyY];
        
        [[func Polilinea] setLineWidth:0.1];
        [[func Color] setStroke];

        aPoint.x = [func Xminima];
        aPoint.y = [self valueAt:aPoint.x
                         funcion:func];
        [[func Polilinea] moveToPoint:aPoint];
        while (aPoint.x <= [func Xmaxima])
        {
            aPoint.y = [self valueAt:aPoint.x
                             funcion:func];
            [[func Polilinea] lineToPoint:aPoint];
            aPoint.x += distance;
        }
        [[func Polilinea] stroke];
        
        [ctx restoreGraphicsState];
        
    }
}


@end
