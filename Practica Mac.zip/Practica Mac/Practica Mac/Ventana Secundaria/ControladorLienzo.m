//
//  ControladorLienzo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "ControladorLienzo.h"
#import "Funcion.h"
#import "VistaLienzo.h"

@interface ControladorLienzo ()


@end


@implementation ControladorLienzo
@synthesize Funciones;

extern NSString * ETPanelChangeTableNotification;
NSString * ETPanelAñadir = @"ETPanelAñadir";


- (id) init {
    if (![super initWithWindowNibName:@"ControladorLienzo"])
        return nil;
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserver:self
           selector:@selector(handlePanelChange:) name:ETPanelChangeTableNotification object:nil];
    return self;
}
- (id)initWithWindow:(NSWindow *)window
{
    self = [super initWithWindow:window];
    if (self) {
        // Initialization code here.
    }
    return self;
}
- (void)windowDidLoad
{
    [super windowDidLoad];
}

-(void) handlePanelChange:(NSNotification *)aNotification
{

    NSDictionary *notinfo =[NSDictionary dictionaryWithObject:Funciones forKey:@"func"];
    NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
    [nc postNotificationName:ETPanelAñadir object:self
                        userInfo:notinfo];

}


-(void) drawInFunction: (NSRect)b
   withGraphicsContext:(NSGraphicsContext *)ctx{
    
    for (Funcion *p in Funciones){
        [p drawInRect:b withGraphicsContext:ctx withFuncion:p];
    }
}

@end
