//
//  ControladorLienzo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "ControladorLienzo.h"
#import "Funcion.h"
#import "VistaLienzo.h"

@interface ControladorLienzo ()


@end


@implementation ControladorLienzo
@synthesize Funciones;

extern NSString * ETPanelChangeTableNotification;
NSString * ETPanelAñadir = @"ETPanelAñadir";


- (id) init {
    if (![super initWithWindowNibName:@"ControladorLienzo"])
        return nil;
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserver:self
           selector:@selector(handlePanelChange:) name:ETPanelChangeTableNotification object:nil];
   // v =[[VistaLienzo alloc]init];
    return self;
}
- (id)initWithWindow:(NSWindow *)window
{
    self = [super initWithWindow:window];
    if (self) {
        // Initialization code here.
    }
    return self;
}
- (void)windowDidLoad
{
    [super windowDidLoad];
    NSLog(@"Fichero NIB cargado");
}

-(void) handlePanelChange:(NSNotification *)aNotification
{
   // NSLog(@"Notificación %@ recibida en handlePanelChange\n",aNotification);
    
    NSDictionary *notinfo =[aNotification userInfo];
    NSString * opcion1 =[notinfo objectForKey:@"No"];
   
    NSLog(@"OBJETO EN EL INDICE 26 ES: %d",[Funciones count]);
    if(opcion1!=nil){
        NSDictionary *notinfo =[NSDictionary dictionaryWithObject:Funciones forKey:@"func"];
        NSNotificationCenter * nc =[NSNotificationCenter defaultCenter];
        [nc postNotificationName:ETPanelAñadir object:self
                        userInfo:notinfo];
    }
     //   NSLog(@"Notificación %@ recibida en handlePanelChange\n",aNotification);
   // v = [[VistaLienzo alloc] init];
   // VistaLienzo *v;
    [v Actualiza];
    [v setArray:Funciones];
}


-(void) drawInFunction: (NSRect)b
   withGraphicsContext:(NSGraphicsContext *)ctx{
    NSLog(@"OBJETO EN EL INDICE 33 ES: %d",[Funciones count]);
    //NSLog(@"OBJETO EN EL INDICE 44 ES: %@",[Funciones count]);
    
    Funcion *p;
    for (Funcion *p in Funciones){
        [p drawInRect:b withGraphicsContext:ctx withFuncion:p];
    }
   // VistaLienzo *v;
    [v Actualiza];
}

@end
