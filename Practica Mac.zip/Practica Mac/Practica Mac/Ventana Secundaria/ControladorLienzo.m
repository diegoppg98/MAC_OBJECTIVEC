//
//  ControladorLienzo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "ControladorLienzo.h"
#import "Funcion.h"
#import "VistaLienzo.h"

@interface ControladorLienzo ()


@end


@implementation ControladorLienzo
@synthesize Funciones;

extern NSString * ETPanelChangeTableNotification;


- (id) init {
    if (![super initWithWindowNibName:@"ControladorLienzo"])
        return nil;
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserver:self
           selector:@selector(handlePanelChange:) name:ETPanelChangeTableNotification object:nil];
    return self;
}
- (id)initWithWindow:(NSWindow *)window
{
    self = [super initWithWindow:window];
    if (self) {
        // Initialization code here.
    }
    return self;
}
- (void)windowDidLoad
{
    [super windowDidLoad];
    NSLog(@"Fichero NIB cargado");
}

-(void) handlePanelChange:(NSNotification *)aNotification
{
    NSLog(@"Notificación %@ recibida en handlePanelChange\n",aNotification);
    v = [[VistaLienzo alloc] init];
    [v Actualiza];
}

- (NSMutableArray *) FuncionesRepresentar{
     NSLog(@"OBJETO EN EL INDICE 1111 ES: %d",[Funciones count]);
    return Funciones;
}
-(void) drawInFunction: (NSRect)b
   withGraphicsContext:(NSGraphicsContext *)ctx{
    
}

@end
