//
//  VistaLienzo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "VistaLienzo.h"
#import "Funcion.h"
#import "ControladorLienzo.h"


@implementation VistaLienzo
@synthesize Array;
extern NSString * ETPanelAñadir;

- (id) initWithCoder:(NSCoder *)VistaLienzo{
    self = [super initWithCoder:VistaLienzo];
   
    if (self) {
       // p =[[ControladorLienzo alloc]init];
        Array = [[NSMutableArray alloc]init];
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc addObserver:self
               selector:@selector(handlePanelAñadir:) name:ETPanelAñadir object:nil];
    }
    return self;
}
-(void)awakeFromNib{
    
    
}

- (void)drawRect:(NSRect)dirtyRect {
    NSLog(@"ENTRAMOS EN DRAW");
    [super drawRect:dirtyRect];
    [[NSColor blackColor] set];
    NSRectFill([self bounds]);
    // Drawing code here.
   NSRect bounds = [self bounds];
    [[NSColor blackColor] set];
    [NSBezierPath fillRect:bounds];
    NSGraphicsContext * ctx = [NSGraphicsContext currentContext];
   // ControladorLienzo * c;
    
   // [p drawInFunction:bounds withGraphicsContext:ctx];
    
   // p = [p FuncionesRepresentar];
    //NSLog(@"OBJETO EN EL INDICE 99 ES: %d",[[p Funciones]count]);
   // NSMutableArray *f;
   // Funcion * nuevaFuncion;
   // nuevaFuncion =[[Funcion alloc] initWithNombre:@"sin(x)" TipoFuncion: @"sin(x)"  Xminima:0 Xmaxima:6.28 Var1:6 Var2:5 Var3:6 ];
    //[nuevaFuncion drawInRect:bounds withGraphicsContext:ctx withFuncion:nuevaFuncion];
    //f=[p FuncionesRepresentar];
    /*//f= [p Funciones];
    
    //int pepe = (int) [f count];
    NSLog(@"OBJETO EN EL INDICE 1 ES: %d",pepe);*/
  //  Funcion *nuevaFuncion;
    NSLog(@"OBJETO EN EL INDICE 40 ES: %d",[Array count]);
    for (Funcion *nuevaFuncion in Array){
        
        [nuevaFuncion drawInRect:bounds withGraphicsContext:ctx withFuncion:nuevaFuncion];
    }
    [self setNeedsDisplay:YES];
}

-(void) Actualiza{
     [self setNeedsDisplay:YES];
    NSLog(@"ENTRAMOS EN ACTUALIZA");
    //NSLog(@"OBJETO EN EL INDICE 40 ES: %d",[Array count]);
}

-(void) handlePanelAñadir:(NSNotification *)aNotification
{
    // NSLog(@"Notificación %@ recibida en handlePanelChange\n",aNotification);
    
    NSDictionary *notinfo =[aNotification userInfo];
    NSMutableArray * f =[notinfo objectForKey:@"func"];
    NSLog(@"OBJETO EN EL INDICE 50 ES: %d",[f count]);
   // NSLog(@"OBJETO EN EL INDICE 26 ES: %d",[Funciones count]);
     if(f!=nil)
         [self setArray:f];
    //   NSLog(@"Notificación %@ recibida en handlePanelChange\n",aNotification);
    // v = [[VistaLienzo alloc] init];
    // VistaLienzo *v;
    [self setNeedsDisplay:YES];
    
}

@end
