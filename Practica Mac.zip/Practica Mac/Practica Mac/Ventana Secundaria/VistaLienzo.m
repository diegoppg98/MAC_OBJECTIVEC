//
//  VistaLienzo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "VistaLienzo.h"
#import "Funcion.h"
#import "ControladorLienzo.h"

@implementation VistaLienzo

- (id) initWithCoder:(NSCoder *)VistaLienzo{
    self = [super initWithCoder:VistaLienzo];
   
    if (self) {
        
    }
    return self;
}
-(void)awakeFromNib{
    
    
}

- (void)drawRect:(NSRect)dirtyRect {
    NSLog(@"ENTRAMOS EN DRAW");
    [super drawRect:dirtyRect];
    [[NSColor blackColor] set];
    NSRectFill([self bounds]);
    // Drawing code here.
   NSRect bounds = [self bounds];
    [[NSColor blackColor] set];
    [NSBezierPath fillRect:bounds];
    NSGraphicsContext * ctx = [NSGraphicsContext currentContext];
    
    
    NSMutableArray *f;
    Funcion * nuevaFuncion;
    nuevaFuncion =[[Funcion alloc] initWithNombre:@"sin(x)" TipoFuncion: @"sin(x)"  Xminima:0 Xmaxima:6.28 Var1:6 Var2:5 Var3:6 ];
    [nuevaFuncion drawInRect:bounds withGraphicsContext:ctx withFuncion:nuevaFuncion];
    //f=[p FuncionesRepresentar];
    /*//f= [p Funciones];
    
    //int pepe = (int) [f count];
    NSLog(@"OBJETO EN EL INDICE 1 ES: %d",pepe);
    Funcion *nuevaFuncion;
    for (Funcion *pp in f){
     [nuevaFuncion drawInRect:bounds withGraphicsContext:ctx withFuncion:pp];
    }*/
    [self setNeedsDisplay:YES];
}

-(void) Actualiza{
     [self setNeedsDisplay:YES];
    NSLog(@"ENTRAMOS EN ACTUALIZA");
}

@end
