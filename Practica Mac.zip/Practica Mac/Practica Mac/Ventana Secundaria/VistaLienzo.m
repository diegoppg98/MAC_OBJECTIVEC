//
//  VistaLienzo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "VistaLienzo.h"
#import "Funcion.h"
#import "ControladorLienzo.h"


@implementation VistaLienzo
@synthesize Array;
extern NSString * ETPanelAñadir;

- (id) initWithCoder:(NSCoder *)VistaLienzo{
    self = [super initWithCoder:VistaLienzo];
   
    if (self) {
       // p =[[ControladorLienzo alloc]init];
        Array = [[NSMutableArray alloc]init];
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc addObserver:self
               selector:@selector(handlePanelAñadir:) name:ETPanelAñadir object:nil];
    }
    return self;
}
-(void)awakeFromNib{
    
    
}

- (void)drawRect:(NSRect)dirtyRect {
    NSLog(@"ENTRAMOS EN DRAW");
    [super drawRect:dirtyRect];
    [[NSColor blackColor] set];
    NSRectFill([self bounds]);
    // Drawing code here.
   NSRect bounds = [self bounds];
    [[NSColor blackColor] set];
    [NSBezierPath fillRect:bounds];
    NSGraphicsContext * ctx = [NSGraphicsContext currentContext];
    
    
    for (Funcion *nuevaFuncion in Array){
        
        [nuevaFuncion drawInRect:bounds withGraphicsContext:ctx withFuncion:nuevaFuncion];
    }
    [self setNeedsDisplay:YES];
}


-(void) Actualiza{
     [self setNeedsDisplay:YES];
    NSLog(@"ENTRAMOS EN ACTUALIZA");
    //NSLog(@"OBJETO EN EL INDICE 40 ES: %d",[Array count]);
}

-(void) handlePanelAñadir:(NSNotification *)aNotification
{
    
    NSDictionary *notinfo =[aNotification userInfo];
    NSMutableArray * f =[notinfo objectForKey:@"func"];

     if(f!=nil)
         [self setArray:f];

    [self setNeedsDisplay:YES];
    
}

- (void)viewWillStartLiveResize{
     [self setNeedsDisplay:YES];
     NSLog(@"Fichero ");
}

@end
