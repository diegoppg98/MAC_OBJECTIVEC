//
//  VistaLienzo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "VistaLienzo.h"
#import "ControladorLienzo.h"


@implementation VistaLienzo
@synthesize Array,TamPantalla;
extern NSString * ETPanelAñadir;
extern NSString * ETPanelPantalla;

- (id) initWithCoder:(NSCoder *)VistaLienzo{
    self = [super initWithCoder:VistaLienzo];
   
    if (self) {
        Array = [[NSMutableArray alloc]init];
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc addObserver:self
               selector:@selector(handlePanelAñadir:) name:ETPanelAñadir object:nil];
        [nc addObserver:self
               selector:@selector(handlePanelPantalla:) name:ETPanelPantalla object:nil];
    }
    return self;
}
-(void)awakeFromNib{
     NSRect Rect = {-10,-10,20,20};
    [self setTamPantalla: Rect];
}

- (void)drawRect:(NSRect)dirtyRect {
    ControladorLienzo *c;
    if(c==nil)
       c= [[ControladorLienzo alloc]init];
    
    NSLog(@"ENTRAMOS EN DRAW");
    [super drawRect:dirtyRect];

    [[NSColor whiteColor] set];
    NSRectFill([self bounds]);
    // Drawing code here.
   NSRect bounds = [self bounds];
    [NSBezierPath fillRect:bounds];
    
    NSGraphicsContext * ctx = [NSGraphicsContext currentContext];
    
    for (Funcion *nuevaFuncion in Array){
        [c drawInRect:bounds withGraphicsContext:ctx withFuncion:nuevaFuncion withTamPantalla: TamPantalla];
    }

    [self setNeedsDisplay:YES];
}


-(void) handlePanelAñadir:(NSNotification *)aNotification
{
    NSDictionary *notinfo =[aNotification userInfo];
    NSMutableArray * f =[notinfo objectForKey:@"func"];
    
    if(f!=nil)
        [self setArray:f];
    
    [self setNeedsDisplay:YES];

}

-(void) handlePanelPantalla:(NSNotification *)aNotification
{
     NSDictionary *notinfo =[aNotification userInfo];
     TamPantalla * tam =[notinfo objectForKey:@"pant"];
     if(tam!=nil){
         NSRect Rect = {[tam Xmin],[tam Ymin],[tam Xmax]-[tam Xmin],[tam Ymax]-[tam Ymin]};
         [self setTamPantalla:Rect];
     }
    
    [self setNeedsDisplay:YES];
    
}


@end
