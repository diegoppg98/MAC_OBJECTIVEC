//
//  ControladorLienzo.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Funcion.h"
#import "TamPantalla.h"
#define HOPS (500)

@class VistaLienzo;

@interface ControladorLienzo : NSWindowController{
    NSMutableArray *Funciones;
}
@property (nonatomic, copy) NSMutableArray *Funciones;

-(void) handlePanelChange:(NSNotification *)aNotification;
-(void) drawEjes: (NSRect)b
withGraphicsContext:(NSGraphicsContext *)ctx;

-(float) valueAt: (float) x
         funcion: (Funcion *) func;
-(void) drawInRect: (NSRect)b
withGraphicsContext:(NSGraphicsContext *)ctx
       withFuncion:(Funcion *)func
   withTamPantalla:(NSRect)funcRect;
@end
