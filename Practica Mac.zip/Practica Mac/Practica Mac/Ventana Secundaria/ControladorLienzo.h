//
//  ControladorLienzo.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class VistaLienzo;

@interface ControladorLienzo : NSWindowController{
    NSMutableArray *Funciones;
    VistaLienzo * v;
}
@property (nonatomic, copy) NSMutableArray *Funciones;

-(void) handlePanelChange:(NSNotification *)aNotification;
-(void) drawInFunction: (NSRect)b
   withGraphicsContext:(NSGraphicsContext *)ctx;
- (NSMutableArray *) FuncionesRepresentar;
@end
