//
//  VistaLienzo.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class ControladorLienzo;

@interface VistaLienzo : NSView{
   // ControladorLienzo * p;
    NSMutableArray *Array;
}
-(void) Actualiza;
@property (nonatomic, copy) NSMutableArray *Array;

@end
