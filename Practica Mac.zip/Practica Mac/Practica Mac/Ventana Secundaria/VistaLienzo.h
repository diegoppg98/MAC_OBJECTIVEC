//
//  VistaLienzo.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "TamPantalla.h"
#import "Funcion.h"
@class ControladorLienzo;

@interface VistaLienzo : NSView{
    NSMutableArray *Array;
    NSRect TamPantalla;
    NSColor *ColorPantalla;
}
-(void) Actualiza;
@property (nonatomic, copy) NSMutableArray *Array;
@property (nonatomic, copy) NSColor *ColorPantalla;
@property (nonatomic) NSRect TamPantalla;

@end
