//
//  TamPantalla.m
//  Practica Mac
//
//  Created by alumno5 on 19/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "TamPantalla.h"

@implementation TamPantalla
@synthesize Xmin, Xmax, Ymin, Ymax;

- (id) init {
    self = [super init];
    if (self){
        [self setXmin:-10];
        [self setXmax:10];
        [self setYmin:-10];
        [self setYmax:10];
    }
    return self;
}

@end
