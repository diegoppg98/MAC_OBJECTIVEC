//
//  Modelo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "Modelo.h"
#import "Funcion.h"

@implementation Modelo
@synthesize aArray;

- (id) init {
    self = [super init];
    if (self){
        aArray = [[NSMutableArray alloc]init];
    }
    return self;
}

- (NSInteger) numberOfRows{
    return [aArray count];
}

- (NSString *) FuncionPintar: (NSInteger)row{
    if([[aArray objectAtIndex:row] Pintar]==TRUE)
        return @"Si";
    else 
        return @"No";
}

- (void)AñadirFuncion: (id)funcion{
    [aArray addObject:funcion];
}

- (void)EliminarFuncion: (NSInteger)x{
    [aArray removeObjectAtIndex:x];
}

- (void) RepresentarFuncion: (NSInteger)x{
    [[aArray objectAtIndex:x] setPintar:TRUE];
}

- (void) NoRepresentarFuncion: (NSInteger)x{
    [[aArray objectAtIndex:x] setPintar:NO];
}
@end
