//
//  Modelo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "Modelo.h"
#import "Funcion.h"

@implementation Modelo
@synthesize aArray;

- (id) init {
    self = [super init];
    if (self){
        aArray = [[NSMutableArray alloc]init];
    }
    return self;
}

- (NSInteger) numberOfRows{
    return [aArray count];
}

- (NSString *) FuncionNombre: (NSInteger)row{
    return [[aArray objectAtIndex:row] Nombre];
}

- (NSString *) FuncionTipoFuncion: (NSInteger)row{
    return [[aArray objectAtIndex:row] TipoFuncion];
}

- (NSInteger) FuncionXmin: (NSInteger)row{
    return [[aArray objectAtIndex:row] Xminima];
}

- (NSInteger) FuncionXmax: (NSInteger)row{
    return [[aArray objectAtIndex:row] Xmaxima];
}
- (NSInteger) FuncionVar1: (NSInteger)row{
    return [[aArray objectAtIndex:row] Var1];
}

- (NSInteger) FuncionVar2: (NSInteger)row{
    return [[aArray objectAtIndex:row] Var2];
}

- (NSInteger) FuncionVar3: (NSInteger)row{
    return [[aArray objectAtIndex:row] Var3];
}

- (bool)AñadirFuncion: (id)funcion{
    [aArray addObject:funcion];
    // NSLog(@"LA CUENTA ES: %d",[aArray count]);
    return true;
}
@end
