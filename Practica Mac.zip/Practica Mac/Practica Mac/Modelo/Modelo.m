//
//  Modelo.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "Modelo.h"
#import "Funcion.h"

@implementation Modelo
@synthesize aArray;

- (id) init {
    self = [super init];
    if (self){
        aArray = [[NSMutableArray alloc]init];
    }
    return self;
}

- (NSInteger) numberOfRows{
    return [aArray count];
}

- (NSString *) FuncionNombre: (NSInteger)row{
    return [[aArray objectAtIndex:row] Nombre];    
}

- (NSString *) FuncionTipoFuncion: (NSInteger)row{
    return [[aArray objectAtIndex:row] TipoFuncion];
}

- (float) FuncionXmin: (NSInteger)row{
    return [[aArray objectAtIndex:row] Xminima];
}

- (float) FuncionXmax: (NSInteger)row{
    return [[aArray objectAtIndex:row] Xmaxima];
}
- (float) FuncionVar1: (NSInteger)row{
    return [[aArray objectAtIndex:row] Var1];
}

- (float) FuncionVar2: (NSInteger)row{
    return [[aArray objectAtIndex:row] Var2];
}

- (float) FuncionVar3: (NSInteger)row{
    return [[aArray objectAtIndex:row] Var3];
}

- (NSString *) FuncionPintar: (NSInteger)row{
    if([[aArray objectAtIndex:row] Pintar]==TRUE)
        return @"Si";
    else 
        return @"No";
}

- (void)AñadirFuncion: (id)funcion{
    [aArray addObject:funcion];
}

- (void)EliminarFuncion: (NSInteger)x{
    [aArray removeObjectAtIndex:x];
}

- (void) RepresentarFuncion: (NSInteger)x{
    [[aArray objectAtIndex:x] setPintar:TRUE];
}

- (void) NoRepresentarFuncion: (NSInteger)x{
    [[aArray objectAtIndex:x] setPintar:NO];
}
@end
