//
//  Funcion.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
@interface Funcion : NSObject
{
    NSString *Nombre;
    NSString *TipoFuncion;
    float Xminima;
    float Xmaxima;
    float Var1;
    float Var2;
    float Var3;
    NSColor *Color;
    NSBezierPath * Polilinea;
    bool Pintar;
}
@property (nonatomic, copy) NSString *Nombre;
@property (nonatomic, copy) NSString *TipoFuncion;
@property (nonatomic) float Xminima;
@property (nonatomic) float Xmaxima;
@property (nonatomic) float Var1;
@property (nonatomic) float Var2;
@property (nonatomic) float Var3;
@property (nonatomic, copy) NSColor *Color;
@property (nonatomic, copy) NSBezierPath * Polilinea;
@property (nonatomic) bool Pintar;

- (id) initWithNombre: (NSString *) aNombre
          TipoFuncion: (NSString *) TipodeFuncion
              Xminima: (float) min
              Xmaxima: (float) max
                 Var1: (float) V1
                 Var2: (float) V2
                 Var3: (float) V3
                Color: (NSColor *) aColor
                ;

@end
