//
//  Funcion.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
@interface Funcion : NSObject
{
    NSString *Nombre;
    NSString *TipoFuncion;
    int Xminima;
    int Xmaxima;
    int Var1;
    int Var2;
    int Var3;
    NSColor *Color;
    NSBezierPath * Polilinea;
}
@property (nonatomic, copy) NSString *Nombre;
@property (nonatomic, copy) NSString *TipoFuncion;
@property (nonatomic) int Xminima;
@property (nonatomic) int Xmaxima;
@property (nonatomic) int Var1;
@property (nonatomic) int Var2;
@property (nonatomic) int Var3;
@property (nonatomic, copy) NSColor *Color;
@property (nonatomic, copy) NSBezierPath * Polilinea;

- (id) initWithNombre: (NSString *) aNombre
          TipoFuncion: (NSString *) TipodeFuncion
              Xminima: (int) min
              Xmaxima: (int) max
                 Var1: (int) V1
                 Var2: (int) V2
                 Var3: (int) V3
                Color: (NSColor *) aColor
                ;

-(float) valueAt: (float) x
         funcion: (Funcion *) func;
-(void) drawInRect: (NSRect)b
withGraphicsContext:(NSGraphicsContext *)ctx
       withFuncion:(Funcion *)func;

@end
