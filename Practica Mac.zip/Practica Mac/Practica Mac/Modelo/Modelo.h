//
//  Modelo.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

@interface Modelo : NSObject
{
    NSInteger aRowSelected;
    NSMutableArray *aArray;
}
- (NSInteger) numberOfRows;
- (void) AñadirFuncion: (id)funcion;
- (void) EliminarFuncion: (NSInteger)x;
- (void) RepresentarFuncion: (NSInteger)x;
- (void) NoRepresentarFuncion: (NSInteger)x;
- (NSString *) FuncionPintar: (NSInteger)row;
@property (nonatomic, copy) NSMutableArray *aArray;
@end
