//
//  Modelo.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Modelo : NSObject
{
    NSInteger aRowSelected;
    NSMutableArray *aArray;
}
- (NSInteger) numberOfRows;
- (NSString *) FuncionNombre: (NSInteger)row;
- (NSString *) FuncionTipoFuncion: (NSInteger)row;
- (float) FuncionXmin: (NSInteger)row;
- (float) FuncionXmax: (NSInteger)row;
- (float) FuncionVar1: (NSInteger)row;
- (float) FuncionVar2: (NSInteger)row;
- (float) FuncionVar3: (NSInteger)row;
- (void) AñadirFuncion: (id)funcion;
- (void) EliminarFuncion: (NSInteger)x;
- (void) RepresentarFuncion: (NSInteger)x;
- (void) NoRepresentarFuncion: (NSInteger)x;
- (NSString *) FuncionPintar: (NSInteger)row;
@property (nonatomic, copy) NSMutableArray *aArray;
@end
