//
//  Modelo.h
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Modelo : NSObject
{
    NSInteger aRowSelected;
    NSMutableArray *aArray;
}
- (NSInteger) numberOfRows;
- (NSString *) FuncionNombre: (NSInteger)row;
- (NSString *) FuncionTipoFuncion: (NSInteger)row;
- (NSInteger) FuncionXmin: (NSInteger)row;
- (NSInteger) FuncionXmax: (NSInteger)row;
- (NSInteger) FuncionVar1: (NSInteger)row;
- (NSInteger) FuncionVar2: (NSInteger)row;
- (NSInteger) FuncionVar3: (NSInteger)row;
- (bool) AñadirFuncion: (id)funcion;
@end
