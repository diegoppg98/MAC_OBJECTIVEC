//
//  TamPantalla.h
//  Practica Mac
//
//  Created by alumno5 on 19/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TamPantalla : NSObject{
    float Xmin;
    float Xmax;
    float Ymin;
    float Ymax;
}

@property (nonatomic) float Xmin;
@property (nonatomic) float Xmax;
@property (nonatomic) float Ymin;
@property (nonatomic) float Ymax;

@end
