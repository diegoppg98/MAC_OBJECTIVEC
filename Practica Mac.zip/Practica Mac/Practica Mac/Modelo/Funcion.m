//
//  Funcion.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "Funcion.h"
#define HOPS (500)
//static NSRect funcRect = {-10,-10,20,20};

@implementation Funcion
@synthesize Nombre, TipoFuncion, Xminima, Xmaxima, Var1, Var2, Var3, Color, Polilinea, Pintar;

- (id) initWithNombre: (NSString *) aNombre
          TipoFuncion: (NSString *) TipodeFuncion
              Xminima: (float) min
              Xmaxima: (float) max
                 Var1: (float) V1
                 Var2: (float) V2
                 Var3: (float) V3
                Color: (NSColor *) aColor

{
    //NSColor * c = [NSColor colorWithCalibratedRed:0.886f green:0.886f blue:0.886f alpha:1.0f];
    self = [super init]; //Primera línea un método inicializador SIEMPRE
    //invocar el init de la superclase
    if (!self) //Se comprueba que no ha habido ningún problema
        return nil; //con el init de la superclase
    [self setNombre:aNombre];
    [self setTipoFuncion:TipodeFuncion];
    [self setXminima:min];
    [self setXmaxima:max];
    [self setVar1:V1];
    [self setVar2:V2];
    [self setVar3:V3];
    [self setColor:aColor];
    [self setPintar:NO];
    [self setPolilinea:[[NSBezierPath alloc] init]];
    return self;
    
}

-(float) valueAt: (float) x
         funcion: (Funcion *) func{
    float result = 0;
    if([[func TipoFuncion] isEqualToString:@"var1*sin(var2*x)"]) {
        result=[func Var1]*sin([func Var2]*x);
    }
    else if([[func TipoFuncion] isEqualToString:@"var1*cos(var2*x)"]){
        result=[func Var1]*cos([func Var2]*x);
    }
    else if([[func TipoFuncion] isEqualToString:@"var1*x+var2"]){
        result=[func Var1]*x+[func Var2];
    }
    else if([[func TipoFuncion] isEqualToString:@"var1*x^var2"]){
        result=[func Var1]*powf(x, [func Var2]);
    }
    else if([[func TipoFuncion] isEqualToString:@"var1/(var2*x)"]){
        result=[func Var1]/([func Var2]*x);
    }
    else if([[func TipoFuncion] isEqualToString:@"var1*x^2+var2*x+var3"]){
        result=[func Var1]*powf(x, 2)+[func Var2]*x+[func Var3];
    }
    return result;
}
-(void) drawInRect: (NSRect)b
withGraphicsContext:(NSGraphicsContext *)ctx
       withFuncion:(Funcion *)func
    pantalla: (NSRect) funcRect{
    
    if([func Pintar]==YES){
        NSPoint aPoint;
        float distance = ([func Xmaxima]-[func Xminima])/HOPS;
        [Polilinea removeAllPoints];
        [ctx saveGraphicsState];
        NSAffineTransform *tf = [NSAffineTransform transform];
        [tf translateXBy:b.size.width/2 yBy:b.size.height/2];
        [tf scaleXBy:b.size.width/funcRect.size.width
                 yBy:b.size.height/funcRect.size.height];
        [tf concat];
        [Polilinea setLineWidth:0.1];
        [Color setStroke];
        //aPoint.x = funcRect.origin.x;
        aPoint.x = [func Xminima];
        aPoint.y = [self valueAt:aPoint.x
                         funcion:func];
        [Polilinea moveToPoint:aPoint];
        while (aPoint.x <= [func Xmaxima])
        {
            aPoint.y = [self valueAt:aPoint.x
                             funcion:func];
            [Polilinea lineToPoint:aPoint];
            aPoint.x += distance;
        }
        [Polilinea stroke];
        [ctx restoreGraphicsState];
    }
}
@end
