//
//  Funcion.m
//  Practica Mac
//
//  Created by alumno5 on 13/12/18.
//  Copyright © 2018 PedroIndustries. All rights reserved.
//

#import "Funcion.h"

@implementation Funcion
@synthesize Nombre, TipoFuncion, Xminima, Xmaxima, Var1, Var2, Var3, Color, Polilinea, Pintar;

- (id) initWithNombre: (NSString *) aNombre
          TipoFuncion: (NSString *) TipodeFuncion
              Xminima: (float) min
              Xmaxima: (float) max
                 Var1: (float) V1
                 Var2: (float) V2
                 Var3: (float) V3
                Color: (NSColor *) aColor

{
    self = [super init]; //Primera línea un método inicializador SIEMPRE
    //invocar el init de la superclase
    if (!self) //Se comprueba que no ha habido ningún problema
        return nil; //con el init de la superclase
    [self setNombre:aNombre];
    [self setTipoFuncion:TipodeFuncion];
    [self setXminima:min];
    [self setXmaxima:max];
    [self setVar1:V1];
    [self setVar2:V2];
    [self setVar3:V3];
    [self setColor:aColor];
    [self setPintar:NO];
    [self setPolilinea:[[NSBezierPath alloc] init]];
    return self;
    
}


@end
